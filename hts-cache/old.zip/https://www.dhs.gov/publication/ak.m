<!DOCTYPE html>
<html lang="en" dir="ltr" prefix="og: https://ogp.me/ns#">
  <head>
    <meta charset="utf-8" />
<script async src="/sites/default/files/google_analytics/gtag.js?st2xsw"></script>
<script>window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments)};gtag("js", new Date());gtag("set", "developer_id.dMDhkMT", true);gtag("config", "UA-32318423-1", {"groups":"default","anonymize_ip":true,"allow_ad_personalization_signals":false,"custom_map":{"dimension1":"dimension1"},"page_path":"/404.html?page=" + document.location.pathname + document.location.search + "&from=" + document.referrer});gtag("event", "custom", {"dimension1":"(DHS) Department of Homeland Security"});</script>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&amp;l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5KJ3RF8');
</script>
<meta name="description" content=" " />
<link rel="canonical" href="https://www.dhs.gov/page-not-found" />
<meta property="og:site_name" content="U.S. Department of Homeland Security" />
<meta property="og:url" content="https://www.dhs.gov/page-not-found" />
<meta property="og:title" content="Page Not Found | Homeland Security" />
<meta property="og:description" content=" " />
<meta property="og:image" content="https://www.dhs.gov/sites/default/files/2024-02/24_0206_opa_og-image-dhs.jpg" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta property="og:image:alt" content="U.S. Department of Homeland Security" />
<meta name="MobileOptimized" content="width" />
<meta name="HandheldFriendly" content="true" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="icon" href="/themes/custom/dhs_uswds/favicon.ico" type="image/vnd.microsoft.icon" />

    <title>Page Not Found | Homeland Security</title>
    <link rel="stylesheet" media="all" href="/core/assets/vendor/jquery.ui/themes/base/core.css?st2xsw" />
<link rel="stylesheet" media="all" href="/core/assets/vendor/jquery.ui/themes/base/controlgroup.css?st2xsw" />
<link rel="stylesheet" media="all" href="/core/assets/vendor/jquery.ui/themes/base/checkboxradio.css?st2xsw" />
<link rel="stylesheet" media="all" href="/core/assets/vendor/jquery.ui/themes/base/resizable.css?st2xsw" />
<link rel="stylesheet" media="all" href="/core/assets/vendor/jquery.ui/themes/base/button.css?st2xsw" />
<link rel="stylesheet" media="all" href="/core/assets/vendor/jquery.ui/themes/base/dialog.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/core/components/progress.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/core/components/ajax-progress.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/align.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/fieldgroup.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/container-inline.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/clearfix.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/details.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/hidden.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/item-list.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/js.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/nowrap.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/position-container.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/reset-appearance.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/resize.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/system-status-counter.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/system-status-report-counters.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/system-status-report-general-info.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/system/components/tablesort.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/profiles/dhsd8_gov/modules/contrib/extlink_extra/css/extlink_extra.508.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/views/views.module.css?st2xsw" />
<link rel="stylesheet" media="all" href="/core/modules/ckeditor5/css/ckeditor5.dialog.fix.css?st2xsw" />
<link rel="stylesheet" media="all" href="/core/assets/vendor/jquery.ui/themes/base/theme.css?st2xsw" />
<link rel="stylesheet" media="all" href="/modules/contrib/ableplayer/css/ableplayer.min.css?st2xsw" />
<link rel="stylesheet" media="all" href="/modules/contrib/ckeditor_accordion/css/accordion.frontend.css?st2xsw" />
<link rel="stylesheet" media="all" href="/modules/contrib/extlink/extlink.css?st2xsw" />
<link rel="stylesheet" media="all" href="/modules/contrib/wcm_node_feedback/css/wcm_node_feedback.css?st2xsw" />
<link rel="stylesheet" media="all" href="/modules/custom/wcm_survey/css/wcm_survey.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/core/assets/vendor/normalize-css/normalize.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/stable/css/core/normalize-fixes.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/classy/css/components/messages.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/classy/css/components/progress.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/classy/css/components/dialog.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/custom/dhs_uswds/assets/uswds/css/styles.css?st2xsw" />
<link rel="stylesheet" media="all" href="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/assets/css/styles.css?st2xsw" />
<link rel="stylesheet" media="print" href="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/assets/css/print.css?st2xsw" />
<link rel="stylesheet" media="all" href="/libraries/slick-carousel/slick/slick.css?st2xsw" />
<link rel="stylesheet" media="all" href="/libraries/slick-carousel/slick/slick-theme.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/uswds/css/style.css?st2xsw" />
<link rel="stylesheet" media="all" href="/themes/contrib/seven/css/components/dropbutton.component.css?st2xsw" />

    <script src="https://dap.digitalgov.gov/Universal-Federated-Analytics-Min.js?agency=DHS&amp;yt=true" id="_fed_an_ua_tag" async></script>

  </head>
  <body class="path-publication page-node-type-site-page">
        <a href="#main-content" class="visually-hidden focusable skip-link">
      Skip to main content
    </a>
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5KJ3RF8" height="0" width="0" style="display:none;visibility:hidden;"></iframe>
</noscript>
      <div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas>
    
  <section class="usa-banner" aria-label="Official government website">
  <div class="usa-accordion">
    <header class="usa-banner__header">
      <div class="usa-banner__inner">
        <div class="grid-col-auto">
          <img class="usa-banner__header-flag" src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/assets/img/us_flag_small.png" alt="U.S. flag">
        </div>
        <div class="grid-col-fill tablet:grid-col-auto">
          <p class="usa-banner__header-text">An official website of the United States government</p>
          <p class="usa-banner__header-action" aria-hidden="true">Here’s how you know</p>
        </div>
        <button class="usa-accordion__button usa-banner__button"
          aria-expanded="false" aria-controls="gov-banner">
          <span class="usa-banner__button-text">Here’s how you know</span>
        </button>
      </div>
    </header>
    <div class="usa-banner__content usa-accordion__content" id="gov-banner">
      <div class="grid-row grid-gap-lg">
        <div class="usa-banner__guidance tablet:grid-col-6">
          <img class="usa-banner__icon usa-media-block__img" src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/assets/img/icon-dot-gov.svg" role="img" alt="Government Website">
          <div class="usa-media-block__body">
            <p>
              <strong>
                Official websites use .gov              </strong>
              <br/>
                              A <strong>.gov</strong> website belongs to an official government organization in the United States.
                          </p>
          </div>
        </div>
        <div class="usa-banner__guidance tablet:grid-col-6">
          <img class="usa-banner__icon usa-media-block__img" src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/assets/img/icon-https.svg" role="img" alt="Safely connect using HTTPS">
          <div class="usa-media-block__body">
            <p>
              <strong>
                Secure .gov websites use HTTPS              </strong>
              <br/>
              A <strong>lock</strong>
                (<span class="icon-lock"><svg xmlns="http://www.w3.org/2000/svg" width="52" height="64" viewBox="0 0 52 64" class="usa-banner__lock-image" role="img" aria-labelledby="banner-lock-title banner-lock-description"><title id="banner-lock-title">Lock</title><desc id="banner-lock-description">A locked padlock</desc><path fill="#000000" fill-rule="evenodd" d="M26 0c10.493 0 19 8.507 19 19v9h3a4 4 0 0 1 4 4v28a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V32a4 4 0 0 1 4-4h3v-9C7 8.507 15.507 0 26 0zm0 8c-5.979 0-10.843 4.77-10.996 10.712L15 19v9h22v-9c0-6.075-4.925-11-11-11z"/></svg></span>)
                or <strong>https://</strong> means you’ve safely connected to the .gov website. Share sensitive information only on official, secure websites.            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<div class="usa-overlay"></div>

  <div class="grid-container header-top">
      <div class="region region-header-top">
    <div class="views-element-container block block-views block-views-blockalert-box-block-1" id="block-views-block-alert-box-block-1">
  
    
      <div><div class="view view-alert-box view-id-alert_box view-display-id-block_1 js-view-dom-id-39fad8256f7844447c4df251f09f390d36ecb6d5dbf5d663e7c33bcb3a262bc5">
  
    
      
  
          </div>
</div>

  </div>

  </div>

  </div>
<header class="usa-header usa-header--basic usa-header--megamenu" role="banner">
      <div class="usa-nav-container">
         <div class="usa-navbar">
          <div class="region region-header">
    
<div class="header-inner">
  <div class="header-logo usa-logo tablet:grid-col-8">

        <a class="logo-img" href="/" accesskey="1" title="Go to the U.S. Department of Homeland Security homepage" aria-label="U.S. Department of Homeland Security homepage link">
      <img src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/logo-wordmark-blue.svg" alt="U.S. Department of Homeland Security logo" />
    </a>
          </div>
  
  <div id="search-block-wrap" class="tablet:grid-col-4" role="searchbox">
    <script async src="https://cse.google.com/cse.js?cx=a8e90417aed6e7a75"></script>
    <div class="gcse-searchbox-only" data-resultsurl="/search" data-defaulttorefinement="DHS.gov" data-gname="dhsallsearch" role="presentation"></div>
  </div>
</div>

  </div>

        <button class="usa-menu-btn">Menu</button>
      </div>

      <nav aria-label="Primary navigation" class="usa-nav" role="navigation">
        <button class="usa-nav__close">
          <img src="/themes/custom/dhs_uswds/assets/uswds/img/usa-icons/close-white.svg" alt="close" />
        </button>
        
                            <div class="region region-primary-menu">
      
  
          <div class="usa-nav__secondary">
        <div class="usa-searchbar-mobile">
            <div id="mobile-search-block-wrap" class="tablet:grid-col-4">
             <form class="usa-search usa-search--small" id="emerald-custom-search-form" action="/search" role="search">
                <label class="usa-sr-only" for="header-search-bar1">Enter Search Term</label>
                <input class="usa-input" tabindex="0" id="header-search-bar1" type="search" placeholder="Enter Search Term" name="search_api_fulltext">
                <button class="usa-button" id="search-button" tabindex="0" type="submit" title="Search"><img src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/assets/img/usa-icons-bg/search--white.svg" class="usa-search__submit-icon" alt="Search" /></button>
              </form>
            </div>
        </div>
      </div>
      <ul class="usa-nav__primary usa-accordion">
    
    
    
              <li class="usa-nav__primary-item">
      
              <button class="usa-accordion__button usa-nav__link " aria-expanded="false" aria-controls="basic-mega-nav-section-1">
          <span>Topics</span><span class="expansion-indicator"></span>
        </button>
      
                
  
          <div id="basic-mega-nav-section-1" class="usa-nav__submenu usa-megamenu" hidden="">

              <div id="desktop-submenu" class="grid-row grid-gap-4">
          <div class="desktop:grid-col-3">
            <div class="usa-nav__submenu-item">
              <a href="/topics">
                <span><h3>Topics</h3></span>
              </a>
            </div>
          </div>
        </div>


      
        <div id="extra-parent" class="grid-row grid-gap-4">
    
          <div id="mobile-submenu">
        <div class="usa-col">
          <div class="usa-nav__submenu-item">
            <a href="/topics" >
              <span>Topics</span>
            </a>
          </div>
        </div>
      </div>
    
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/border-security" tabindex="0">
          <span>Border Security</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/citizenship-and-immigration-services" tabindex="0">
          <span>Citizenship and Immigration</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/cybersecurity" tabindex="0">
          <span>Cybersecurity</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/disasters" tabindex="0">
          <span>Disasters</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/election-security" tabindex="0">
          <span>Election Security</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/homeland-security-enterprise" tabindex="0">
          <span>Homeland Security Enterprise</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/human-trafficking" tabindex="0">
          <span>Human Trafficking</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/immigration-and-customs-enforcement" tabindex="0">
          <span>Immigration and Customs Enforcement</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/preventing-terrorism-and-targeted-violence" tabindex="0">
          <span>Preventing Terrorism and Targeted Violence</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/resilience" tabindex="0">
          <span>Resilience</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/science-and-technology" tabindex="0">
          <span>Science and Technology</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/trade-and-economic-security" tabindex="0">
          <span>Trade and Economic Security</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/transportation-security" tabindex="0">
          <span>Transportation Security</span>
        </a>
                  </div>
              
              </div>
      
    
            </div>
      </div>
    
  

      
              </li>
      
    
              <li class="usa-nav__primary-item">
      
              <button class="usa-accordion__button usa-nav__link " aria-expanded="false" aria-controls="basic-mega-nav-section-2">
          <span>News</span><span class="expansion-indicator"></span>
        </button>
      
                
  
          <div id="basic-mega-nav-section-2" class="usa-nav__submenu usa-megamenu" hidden="">

              <div id="desktop-submenu" class="grid-row grid-gap-4">
          <div class="desktop:grid-col-3">
            <div class="usa-nav__submenu-item">
              <a href="/news">
                <span><h3>News</h3></span>
              </a>
            </div>
          </div>
        </div>


      
        <div id="extra-parent" class="grid-row grid-gap-4">
    
          <div id="mobile-submenu">
        <div class="usa-col">
          <div class="usa-nav__submenu-item">
            <a href="/news" >
              <span>News</span>
            </a>
          </div>
        </div>
      </div>
    
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/all-news-updates" tabindex="0">
          <span>All DHS News</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/dhs-citizen-application-directory" tabindex="0">
          <span>Apps</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/news-releases/blog" tabindex="0">
          <span>Blog</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/comunicados-de-prensa" tabindex="0">
          <span>Comunicados de Prensa</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/data" tabindex="0">
          <span>Data</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/events" tabindex="0">
          <span>Events</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/news-releases/fact-sheets" tabindex="0">
          <span>Fact Sheets</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/news-releases/featured" tabindex="0">
          <span>Featured News</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/live" tabindex="0">
          <span>Homeland Security LIVE</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/media-contacts" tabindex="0">
          <span>Media Contacts</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/medialibrary" tabindex="0">
          <span>Media Library</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/national-terrorism-advisory-system" tabindex="0">
          <span>National Terrorism Advisory System</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/news-releases/press-releases" tabindex="0">
          <span>Press Releases</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/publications" tabindex="0">
          <span>Publications Library</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/social-media-directory" tabindex="0">
          <span>Social Media</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/news-releases/speeches" tabindex="0">
          <span>Speeches</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="https://public.govdelivery.com/accounts/USDHS/subscriber/new" tabindex="0">
          <span>Subscribe</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/news-releases/testimony" tabindex="0">
          <span>Testimony</span>
        </a>
                  </div>
              
              </div>
      
    
            </div>
      </div>
    
  

      
              </li>
      
    
              <li class="usa-nav__primary-item">
      
              <button class="usa-accordion__button usa-nav__link " aria-expanded="false" aria-controls="basic-mega-nav-section-3">
          <span>In Focus</span><span class="expansion-indicator"></span>
        </button>
      
                
  
          <div id="basic-mega-nav-section-3" class="usa-nav__submenu usa-megamenu" hidden="">

              <div id="desktop-submenu" class="grid-row grid-gap-4">
          <div class="desktop:grid-col-3">
            <div class="usa-nav__submenu-item">
              <a href="/focus">
                <span><h3>In Focus</h3></span>
              </a>
            </div>
          </div>
        </div>


      
        <div id="extra-parent" class="grid-row grid-gap-4">
    
          <div id="mobile-submenu">
        <div class="usa-col">
          <div class="usa-nav__submenu-item">
            <a href="/focus" >
              <span>In Focus</span>
            </a>
          </div>
        </div>
      </div>
    
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/topics/cybersecurity" tabindex="0">
          <span>Cybersecurity</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/fentanyl" tabindex="0">
          <span>Fentanyl</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/independent-review-2024-attempted-assassination" tabindex="0">
          <span>Independent Review of 2024 Attempted Assassination</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/making-america-safe-again" tabindex="0">
          <span>Making America Safe Again</span>
        </a>
                  </div>
              
              </div>
      
    
            </div>
      </div>
    
  

      
              </li>
      
    
              <li class="usa-nav__primary-item">
      
              <button class="usa-accordion__button usa-nav__link " aria-expanded="false" aria-controls="basic-mega-nav-section-4">
          <span>How Do I?</span><span class="expansion-indicator"></span>
        </button>
      
                
  
          <div id="basic-mega-nav-section-4" class="usa-nav__submenu usa-megamenu" hidden="">

              <div id="desktop-submenu" class="grid-row grid-gap-4">
          <div class="desktop:grid-col-3">
            <div class="usa-nav__submenu-item">
              <a href="/how-do-i">
                <span><h3>How Do I?</h3></span>
              </a>
            </div>
          </div>
        </div>


      
        <div id="extra-parent" class="grid-row grid-gap-4">
    
          <div id="mobile-submenu">
        <div class="usa-col">
          <div class="usa-nav__submenu-item">
            <a href="/how-do-i" >
              <span>How Do I?</span>
            </a>
          </div>
        </div>
      </div>
    
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/how-do-i-alphabetical" tabindex="0">
          <span>Alphabetical Listing</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/how-do-i/at-dhs" tabindex="0">
          <span>At DHS</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/how-do-i/for-businesses" tabindex="0">
          <span>For Businesses</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/how-do-i/for-travelers" tabindex="0">
          <span>For Travelers</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/how-do-i/for-the-public" tabindex="0">
          <span>For the Public</span>
        </a>
                  </div>
              
              </div>
      
    
            </div>
      </div>
    
  

      
              </li>
      
    
              <li class="usa-nav__primary-item">
      
              <button class="usa-accordion__button usa-nav__link " aria-expanded="false" aria-controls="basic-mega-nav-section-5">
          <span>Get Involved</span><span class="expansion-indicator"></span>
        </button>
      
                
  
          <div id="basic-mega-nav-section-5" class="usa-nav__submenu usa-megamenu" hidden="">

              <div id="desktop-submenu" class="grid-row grid-gap-4">
          <div class="desktop:grid-col-3">
            <div class="usa-nav__submenu-item">
              <a href="/get-involved">
                <span><h3>Get Involved</h3></span>
              </a>
            </div>
          </div>
        </div>


      
        <div id="extra-parent" class="grid-row grid-gap-4">
    
          <div id="mobile-submenu">
        <div class="usa-col">
          <div class="usa-nav__submenu-item">
            <a href="/get-involved" >
              <span>Get Involved</span>
            </a>
          </div>
        </div>
      </div>
    
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="https://www.cisa.gov/be-cyber-smart" tabindex="0">
          <span>#BeCyberSmart</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/blue-campaign" tabindex="0">
          <span>Blue Campaign</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="https://www.ready.gov/citizen-corps" tabindex="0">
          <span>Citizen Corps</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/see-something-say-something" tabindex="0">
          <span>If You See Something, Say Something®</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/know2protect" tabindex="0">
          <span>Know2Protect</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/nationwide-sar-initiative-nsi" tabindex="0">
          <span>Nationwide SAR Initiative</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/real-id" tabindex="0">
          <span>REAL ID</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="https://www.ready.gov" tabindex="0">
          <span>Ready.gov</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/stopthebleed" tabindex="0">
          <span>Stop the Bleed</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/us-coast-guard-auxiliary" tabindex="0">
          <span>US Coast Guard Auxiliary</span>
        </a>
                  </div>
              
              </div>
      
    
            </div>
      </div>
    
  

      
              </li>
      
    
              <li class="usa-nav__primary-item">
      
              <button class="usa-accordion__button usa-nav__link " aria-expanded="false" aria-controls="basic-mega-nav-section-6">
          <span>About DHS</span><span class="expansion-indicator"></span>
        </button>
      
                
  
          <div id="basic-mega-nav-section-6" class="usa-nav__submenu usa-megamenu" hidden="">

              <div id="desktop-submenu" class="grid-row grid-gap-4">
          <div class="desktop:grid-col-3">
            <div class="usa-nav__submenu-item">
              <a href="/about-dhs">
                <span><h3>About DHS</h3></span>
              </a>
            </div>
          </div>
        </div>


      
        <div id="extra-parent" class="grid-row grid-gap-4">
    
          <div id="mobile-submenu">
        <div class="usa-col">
          <div class="usa-nav__submenu-item">
            <a href="/about-dhs" >
              <span>About DHS</span>
            </a>
          </div>
        </div>
      </div>
    
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/budget-performance" tabindex="0">
          <span>Budget &amp; Performance</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/contact-us" tabindex="0">
          <span>Contact Us</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/employee-resources" tabindex="0">
          <span>Employee Resources</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/history" tabindex="0">
          <span>History</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/homeland-security-careers" tabindex="0">
          <span>Homeland Security Careers</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/memoriam" tabindex="0">
          <span>In Memoriam</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/laws-regulations" tabindex="0">
          <span>Laws &amp; Regulations</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/leadership" tabindex="0">
          <span>Leadership</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/mission" tabindex="0">
          <span>Mission</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/organization" tabindex="0">
          <span>Organization</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/priorities" tabindex="0">
          <span>Priorities</span>
        </a>
                  </div>
              
              </div>
      
    
              <div class="usa-col">

              
      
                        <div class="usa-nav__submenu-item">
                <a href="/site-links" tabindex="0">
          <span>Site Links</span>
        </a>
                  </div>
              
              </div>
      
    
            </div>
      </div>
    
  

      
              </li>
      
    
          </ul>
    
  




  </div>

        
                
             </nav>

      </div>
  
</header>

 <main class="usa-section" id="main-content">
   <div class="grid-container">
     <div class="grid-row grid-gap">
       <div class="grid-col-12">
           <div class="region region-breadcrumb">
    <div id="block-breadcrumbs" class="block block-system block-system-breadcrumb-block">
  
    
      <h2 id="system-breadcrumb" class="visually-hidden">Breadcrumb</h2>
<ol class="add-list-reset uswds-breadcrumbs uswds-horizontal-list">
  <li>
          <a href="/">Home</a>
      </li>
</ol>

  </div>

  </div>

         

         
      </div>
     </div>

     <div class="grid-row grid-gap">
                    <aside class="tablet:grid-col-3">
            <div class="region region-sidebar-first">
    

  
      <ul class="usa-sidenav">
          
                    
      
      <li class="usa-sidenav__item expanded dropdown first last" >
        <a  href="/publications">
          <span>Publications Library</span>
        </a>

      </li>
                
      <ul class="usa-sidenav__sublist">
          
                    
      
      <li class="usa-sidenav__item first" >
        <a  href="/publications-library/academic-engagement">
          <span>Academic Engagement</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/border-security">
          <span>Border Security</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/office-of-the-citizenship-and-immigration-services-ombudsman">
          <span>Citizenship And Immigration Services Ombudsman</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/citizenship-and-immigration-services">
          <span>Citizenship and Immigration Services</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/civil-rights-and-civil-liberties">
          <span>Civil Rights and Civil Liberties</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/cybersecurity">
          <span>Cybersecurity</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/disasters">
          <span>Disasters</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/do-business-with-dhs">
          <span>Do Business with DHS</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/election-security">
          <span>Election Security</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/homeland-security-careers">
          <span>Homeland Security Careers</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/homeland-security-enterprise">
          <span>Homeland Security Enterprise</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/human-trafficking">
          <span>Human Trafficking</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/immigration-and-customs-enforcement">
          <span>Immigration and Customs Enforcement</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/intelligence-and-analysis">
          <span>Intelligence and Analysis</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/international-engagement">
          <span>International Engagement</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/law-enforcement">
          <span>Law Enforcement</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/national-terrorism-advisory-system">
          <span>National Terrorism Advisory System</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/preventing-terrorism-and-targeted-violence">
          <span>Preventing Terrorism and Targeted Violence</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/privacy">
          <span>Privacy</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/real-id">
          <span>REAL ID</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/resilience">
          <span>Resilience</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/science-and-technology">
          <span>Science and Technology</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/trade-and-economic-security">
          <span>Trade and Economic Security</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item" >
        <a  href="/publications-library/transportation-security">
          <span>Transportation Security</span>
        </a>

      </li>
                
                    
      
      <li class="usa-sidenav__item last" >
        <a  href="/publications-library/weapons-of-mass-destruction">
          <span>Weapons of Mass Destruction</span>
        </a>

      </li>
              </ul>
  
              </ul>
  



  </div>

        </aside>
      
       <div class="region-content tablet:grid-col-12 desktop:grid-col-9">
           <div class="region region-content">
    <div data-drupal-messages-fallback class="hidden"></div><div id="block-dhs-uswds-subtheme-pagetitle" class="block block-core block-page-title-block">
  
    
      
  <h1 class="uswds-page-title page-title">Page Not Found</h1>


  </div>
<div id="block-mainpagecontent" class="block block-system block-system-main-block">
      <article lang="en">

  
    

  
  <div>

    
    
            <div class="field field--name-body field--type-text-with-summary field--label-hidden field__item"><h3><img alt="It looks like K-9 Scout wasn't able to find the page that you are looking for." width="350px" height="370px" style=" margin: 5px;" class="align-right image-style-webp-original-size" src="/sites/default/files/styles/webp_original_size/public/images/opa/404_scout_02.jpg.webp?itok=_Bt3xchZ">

It looks like K-9 Scout wasn't able to find the page that you are searching for.</h3><p>The page may have been moved, deleted, or is otherwise unavailable.</p><p>To help you find what you are looking for, please try one or more of the following:</p><ol><li>Search for what you are looking for in our search box in the upper right corner of this page.</li><li>Check the URL (web address) for proper spelling and completeness.</li></ol></div>
      
  </div>

</article>

  </div>

  </div>

       </div>
            
    </div>
   </div>

   </main>


<div class="usa-footer-container">
  <footer class="usa-footer usa-footer--medium" role="contentinfo">
    <div class="grid-container usa-footer__return-to-top">
      <a href="#" class="focusable">Return to top</a>
    </div>

           <div class="usa-footer__primary-section">
         <div class="grid-container">
           <div class="grid-row grid-gap ">
                                         <div class="usa-footer__primary-section__menu ">
                 <nav class="usa-footer__nav" aria-label="Footer navigation">  <div class="region region-footer-menu">
    

    
                <ul class="grid-row grid-gap add-list-reset">
        
    
                  <li class="mobile-lg:grid-col-4 desktop:grid-col-2 usa-footer__primary-content">
        <a href="/topics" class="usa-footer__primary-link" title="Topics" data-drupal-link-system-path="node/336">Topics</a>
      </li>
      
    
                  <li class="mobile-lg:grid-col-4 desktop:grid-col-2 usa-footer__primary-content">
        <a href="/news" class="usa-footer__primary-link" title="DHS News" data-drupal-link-system-path="node/337">News</a>
      </li>
      
    
                  <li class="mobile-lg:grid-col-4 desktop:grid-col-2 usa-footer__primary-content">
        <a href="/focus" class="usa-footer__primary-link" data-drupal-link-system-path="node/13079">In Focus</a>
      </li>
      
    
                  <li class="mobile-lg:grid-col-4 desktop:grid-col-2 usa-footer__primary-content">
        <a href="/how-do-i" class="usa-footer__primary-link" data-drupal-link-system-path="node/16252">How Do I?</a>
      </li>
      
    
                  <li class="mobile-lg:grid-col-4 desktop:grid-col-2 usa-footer__primary-content">
        <a href="/get-involved" class="usa-footer__primary-link" title="Get Involved" data-drupal-link-system-path="node/282">Get Involved</a>
      </li>
      
    
                  <li class="mobile-lg:grid-col-4 desktop:grid-col-2 usa-footer__primary-content">
        <a href="/about-dhs" class="usa-footer__primary-link" data-drupal-link-system-path="node/283">About DHS</a>
      </li>
      
    
                </ul>
        
  



  </div>

                 </nav>
               </div>
             
                     </div>
                               </div>
       </div>
                            
        <div class="usa-footer__intermediate-section">
          <div class="grid-container">

                      <div class="grid-row grid-gap">
              <div class="usa-footer__logo grid-row mobile-lg:grid-col-6 mobile-lg:grid-gap-2">
                <div class="mobile-lg:grid-col-auto">
                  <img class="usa-footer__logo-img" src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/logo-wordmark-blue.svg" alt="U.S. Department of Homeland Security Seal">
              </div>
                              </div>
                                              
                <div class="usa-footer__contact-links mobile-lg:grid-col-6">
                  <div class="usa-footer__social-links grid-row grid-gap-1">
                                                                  <div class="grid-col-auto">
                          <a class="usa-social-link" href="/facebook" >
                            <img
                              class="usa-social-link__icon"
                              src="/themes/custom/dhs_uswds/img/social-icons/facebook.svg"
                              alt="Facebook" />
                          </a>
                        </div>
                                                                                                                                  <div class="grid-col-auto">
                          <a class="usa-social-link" href="/twitter" >
                            <img
                              class="usa-social-link__icon"
                              src="/themes/custom/dhs_uswds/img/social-icons/x.svg"
                              alt="X" />
                          </a>
                        </div>
                                                                                        <div class="grid-col-auto">
                          <a class="usa-social-link" href="/youtube" >
                            <img
                              class="usa-social-link__icon"
                              src="/themes/custom/dhs_uswds/img/social-icons/youtube.svg"
                              alt="YouTube" />
                          </a>
                        </div>
                                                                                                                                  <div class="grid-col-auto">
                          <a class="usa-social-link" href="/flicker" >
                            <img
                              class="usa-social-link__icon"
                              src="/themes/custom/dhs_uswds/img/social-icons/flickr.svg"
                              alt="Flickr" />
                          </a>
                        </div>
                                                                                        <div class="grid-col-auto">
                          <a class="usa-social-link" href="/instagram" >
                            <img
                              class="usa-social-link__icon"
                              src="/themes/custom/dhs_uswds/img/social-icons/instagram.svg"
                              alt="Instagram" />
                          </a>
                        </div>
                                                                                        <div class="grid-col-auto">
                          <a class="usa-social-link" href="/linkedin" >
                            <img
                              class="usa-social-link__icon"
                              src="/themes/custom/dhs_uswds/img/social-icons/linkedin.svg"
                              alt="LinkedIn" />
                          </a>
                        </div>
                                                                                        <div class="grid-col-auto">
                          <a class="usa-social-link" href="https://public.govdelivery.com/accounts/USDHS/subscriber/new"  target="_blank">
                            <img
                              class="usa-social-link__icon"
                              src="/themes/custom/dhs_uswds/img/social-icons/email.svg"
                              alt="Email" />
                          </a>
                        </div>
                                                            </div>

                                  <address class="usa-footer__address">
                    <div class="usa-footer__contact-info grid-row grid-gap">
                                                                </div>
                  </address>
                </div>
                          </div>
          
          </div>
        </div>
      
    <div class="usa-footer__secondary-section">
      <div class="grid-container">
        <div class="grid-row grid-gap">
          <div class="grid-col-9">
            <section class="usa-identifier__section usa-identifier__section--masthead" aria-label="Agency identifier">
              <div class="usa-identifier__container">
                <div class="usa-identifier__logos">
                  <a href="https://www.dhs.gov" class="usa-identifier__logo">
                    <img class="usa-identifier__logo-img" src="/themes/custom/dhs_uswds/logo.svg" alt="U.S. Department of Homeland Security Seal">
                  </a></div>
                <div class="usa-identifier__identity" aria-label="Agency description">
                  <p class="usa-identifier__identity-domain">DHS.gov</p>
                  <p class="usa-identifier__identity-disclaimer">
                    An official website of the <a href="https://www.dhs.gov">U.S. Department of Homeland Security</a>
                  </p>
                </div>
              </div>
            </section>
              <div class="region region-footer-secondary">
    <nav role="navigation" aria-labelledby="block-dhs-uswds-subtheme-footer-menu" id="block-dhs-uswds-subtheme-footer" class="grid-col-9 block block-menu navigation menu--footer">
            


        <ul class="menu menu--footer nav">
                              <li class="first">
                                                  <a href="/about-dhs" class="first" data-drupal-link-system-path="node/283">About DHS</a>
                  </li>
                              <li>
                                                  <a href="/accessibility" data-drupal-link-system-path="node/53598">Accessibility</a>
                  </li>
                              <li>
                                                  <a href="/performance-financial-reports" data-drupal-link-system-path="node/5067">Budget and Performance</a>
                  </li>
                              <li>
                                                  <a href="/websites" title="DHS Components" data-drupal-link-system-path="node/8968">DHS Components</a>
                  </li>
                              <li>
                                                  <a href="/foia" data-drupal-link-system-path="node/7361">FOIA Requests</a>
                  </li>
                              <li>
                                                  <a href="/homeland-security-no-fear-act-reporting" data-drupal-link-system-path="node/4646">No FEAR Act Data</a>
                  </li>
                              <li>
                                                  <a href="/privacy-policy" data-drupal-link-system-path="node/4652">Privacy Policy</a>
                  </li>
                              <li>
                                                  <a href="/site-links" data-drupal-link-system-path="node/3797">Site Links</a>
                  </li>
                              <li>
                                                  <a href="/report-it-vulnerability" data-drupal-link-system-path="node/55456">Vulnerability Disclosure Program</a>
                  </li>
                              <li>
                                                  <a href="https://www.oig.dhs.gov/" title="Office of the Inspector General">Office of Inspector General</a>
                  </li>
                              <li>
                                                  <a href="https://www.whitehouse.gov" title="The White House">The White House</a>
                  </li>
                              <li class="last">
                                                  <a href="https://www.usa.gov" title="USA.gov" class="last">USA.gov</a>
                  </li>
          </ul>
  

  </nav>

  </div>

                        <section class="usa-identifier__section usa-identifier__section--usagov" aria-label="U.S. government information and services">
              <div class="usa-identifier__container">
                <div class="usa-identifier__usagov-description">Looking for U.S. government information and services?</div>
                <a href="https://www.usa.gov/" class="usa-link" title="Visit the USA.gov website">Visit USA.gov</a>
              </div>
            </section>
          </div>
                      <div class="grid-col-3 ntas-widget">
                <iframe id="ntas-frame" src="https://www.dhs.gov/ntas/" name="NationalTerrorismAdvisorySystem" title="National Terrorism Advisory System" width="170" height="180" scrolling="no" frameborder="0" seamless border="0"></iframe>
            </div>
                  </div>
      </div>
    </div>
  </footer>
</div>


  </div>

    
    <script type="application/json" data-drupal-selector="drupal-settings-json">{"path":{"baseUrl":"\/","pathPrefix":"","currentPath":"","currentPathIsAdmin":false,"isFront":false,"currentLanguage":"en"},"pluralDelimiter":"\u0003","suppressDeprecationErrors":true,"ajaxPageState":{"libraries":"eJx9UdFuwyAM_CEa9jJpf4Mc7BJWgytM0qZfPxqWblq3vWDf-Swbnz8RxirFgfdSMEq2j2w4FsmVMhrPoLraEZT2PJEqBFLTxGSxzGfgASOwhAHe4dr5LCUBxxsZnNR1aUsg--n7TMcxn3TTzHpBtYFlBP4inM5jnSjRPxWNlWI6F1nINFyA0cLIdGZYqRi61vuUfdVPuNOuxQJ2R68vb39UNmSCSGBq_wBea_Rt4R-E0VUrpX6yWY-EQRb31MYCeHjAg8ds-gH6lh04v5sUmx2hQL3b1Eu_mLVEuqjd3iEJzkzm4pPLguSORDiCP9knZtPoXBZabQ8fv_jU4w","theme":"dhs_uswds_subtheme","theme_token":null},"ajaxTrustedUrl":[],"extlink_extra":{"extlink_alert_type":"modal","extlink_modal_width":"420px","extlink_alert_timer":0,"extlink_alert_url":"https:\/\/www.dhs.gov\/now-leaving","extlink_cache_fix":1,"extlink_exclude_warning":"","extlink_508_fix":1,"extlink_508_text":" [external link]","extlink_url_override":0,"extlink_url_params":[]},"google_analytics":{"account":"UA-32318423-1","trackOutbound":true,"trackMailto":true,"trackDownload":true,"trackDownloadExtensions":"7z|aac|arc|arj|asf|asx|avi|bin|csv|doc(x|m)?|dot(x|m)?|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt(x|m)?|pot(x|m)?|pps(x|m)?|ppam|sld(x|m)?|thmx|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls(x|m|b)?|xlt(x|m)|xlam|xml|z|zip"},"wcmSurvey":{"userPercentage":"25","pageDepth":"2","url":"https:\/\/www.surveymonkey.com\/s\/dhs-survey","force":false,"surveyRetakeTimeout":"30","surveyPopup":"\u003Cdiv id=\u0022wcm-survey-popup\u0022 class=\u0022\u0022\u003E\n            \u003Cdiv class=\u0022survey-logo-wrap survey-logo-img\u0022\u003E\n            \u003Cimg id=\u0022survey-logo\u0022 alt=\u0022 Logo\u0022 src=\u0022\/profiles\/dhsd8_gov\/themes\/custom\/dhs_uswds_subtheme\/logo-wordmark-blue.svg\u0022\/\u003E\n        \u003C\/div\u003E\n\n        \u003Cdiv class=\u0022message\u0022\u003E\n        \u003Cp\u003EYou have been selected to participate in a brief survey about your experience today with DHS.gov.\u003C\/p\u003E\r\n\n    \u003C\/div\u003E\n\u003C\/div\u003E\n","survey":{"sid":"1","title":"Thank you for visiting our website.","body":"\u003Cp\u003EYou have been selected to participate in a brief survey about your experience today with DHS.gov.\u003C\/p\u003E\r\n","url":"https:\/\/www.surveymonkey.com\/s\/dhs-survey","targetlang":"en","yeslabel":"Yes, I\u0027ll give feedback","nolabel":"No Thanks","yestitle":"Yes, I\u0027ll give feedback","notitle":"No Thanks, I do not want to give feedback","is_active":"1","patterns":[],"force":false},"debugMode":false,"position":"centered","offset":"","height":"320","width":"","maxHeight":"","maxWidth":"100%"},"data":{"extlink":{"extTarget":false,"extTargetNoOverride":false,"extNofollow":false,"extNoreferrer":true,"extFollowNoOverride":false,"extClass":"ext","extLabel":"(link is external)","extImgClass":false,"extSubdomains":true,"extExclude":"(\\.fayze2\\.com|\\.gov|\\.mil|feedburner\\.com|www\\.facebook\\.com\\\/homelandsecurity|www\\.facebook\\.com\\\/ntasalerts|twitter\\.com|www\\.twitter\\.com|x\\.com|www\\.youtube\\.com\\\/user\\\/ushomelandsecurity|www\\.surveymonkey\\.com|homelandsecurity\\.ideascale\\.com|tel:|sms:|www\\.gocoastguard\\.com|section508testing\\.org|JavaScript:void()|tel:|sms:|www\\.gocoastguard\\.com|itunes\\.apple\\.com|pcast:\\\/\\\/www\\.dhs\\.gov|play\\.google\\.com|dvidshub\\.net|join\\.cgaux\\.org|appengine\\.egov\\.com\\\/apps\\\/ar\\\/DFA\\\/RealID|www\\.guamtax\\.com\\\/about\\\/mvd\\.html|www\\.ksrevenue\\.org\\\/dovrealid\\.html|www\\.expresslane\\.org\\\/Pages\\\/default\\.aspx|dmvnv\\.com\\\/realid\\.htm|www\\.scdmvonline\\.com\\\/Driver\\-Services\\\/Drivers\\-License\\\/REAL\\-ID|www\\.dot\\.state\\.wy\\.us\\\/home\\\/driver\\_license\\_records\\\/driver\\-license\\.html|www\\.youtube\\.com|www\\.facebook\\.com|www\\.linkedin\\.com|www\\.instagram\\.com|www\\.flickr\\.com)","extInclude":"","extCssExclude":"#wcm-survey-popup","extCssExplicit":"","extAlert":false,"extAlertText":"\u0026lt;style type=\u0026quot;text\/css\u0026quot;\u0026gt;.ui-dialog .ui-dialog-titlebar {background-color: #005288;color: #FFFFFF;}\r\n\u0026lt;\/style\u0026gt;\u0026lt;p style=\u0026quot;display:flex;justify-content:center;\u0026quot;\u0026gt;\u0026lt;img style=\u0026quot;height:auto;width:55%;\u0026quot; alt=\u0026quot;\u0026quot; src=\u0026quot;\/themes\/custom\/dhs_uswds\/logo.png\u0026quot;\u0026gt;\u0026lt;\/p\u0026gt;\u0026lt;h4\u0026gt;You are now leaving the Department of Homeland Security\u0026#039;s website and headed towards:\u0026lt;\/h4\u0026gt;\u0026lt;p\u0026gt;[extlink:external-url]\u0026lt;\/p\u0026gt;\u0026lt;p\u0026gt;Are you sure you want to proceed?\u0026lt;\/p\u0026gt;\u0026lt;div class=\u0026quot;usa-button-group\u0026quot;\u0026gt;\u0026lt;div style=\u0026quot;margin:1rem;width:100%;\u0026quot;\u0026gt;\u0026lt;a class=\u0026quot;usa-button\u0026quot; style=\u0026quot;background-color:#477326;color:white;width:100%;\u0026quot; href=\u0026quot;[extlink:external-url]\u0026quot;\u0026gt;Yes\u0026lt;\/a\u0026gt;\u0026lt;\/div\u0026gt;\u0026lt;div style=\u0026quot;margin:1rem;width:100%;\u0026quot;\u0026gt;\u0026lt;a class=\u0026quot;usa-button usa-button--outline\u0026quot; style=\u0026quot;color:#005288;width:100%;\u0026quot; href=\u0026quot;[extlink:back-url]\u0026quot;\u0026gt;No, return to DHS.gov\u0026lt;\/a\u0026gt;\u0026lt;\/div\u0026gt;\u0026lt;\/div\u0026gt;\u0026lt;p\u0026gt;For more information, read the \u0026lt;a href=\u0026quot;https:\/\/www.dhs.gov\/linking-policy\u0026quot; title=\u0026quot;Linking Policy\u0026quot;\u0026gt;DHS.gov linking policy\u0026lt;\/a\u0026gt;.\u0026lt;\/p\u0026gt;","mailtoClass":"mailto","mailtoLabel":"(link sends email)","extUseFontAwesome":false,"extIconPlacement":"before","extFaLinkClasses":"fa fa-external-link","extFaMailtoClasses":"fa fa-envelope-o","whitelistedDomains":[]}},"ckeditorAccordion":{"accordionStyle":{"collapseAll":null,"keepRowsOpen":null,"animateAccordionOpenAndClose":1,"openTabsWithHash":1}},"user":{"uid":0,"permissionsHash":"52d6a3bb295cf7c2a1d5c92b11d326d799303e25ee5fc2307af6f716f315f007"}}</script>
<script src="/core/assets/vendor/jquery/jquery.min.js?v=3.7.1"></script>
<script src="/core/assets/vendor/once/once.min.js?v=1.0.1"></script>
<script src="/core/misc/drupalSettingsLoader.js?v=10.4.3"></script>
<script src="/core/misc/drupal.js?v=10.4.3"></script>
<script src="/core/misc/drupal.init.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/version-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/data-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/disable-selection-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/jquery-patch-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/scroll-parent-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/unique-id-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/focusable-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/keycode-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/plugin-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/widget-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/labels-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/widgets/controlgroup-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/form-reset-mixin-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/widgets/mouse-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/widgets/checkboxradio-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/widgets/draggable-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/widgets/resizable-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/widgets/button-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/jquery.ui/ui/widgets/dialog-min.js?v=10.4.3"></script>
<script src="/core/assets/vendor/tabbable/index.umd.min.js?v=6.2.0"></script>
<script src="/core/assets/vendor/tua-body-scroll-lock/tua-bsl.umd.min.js?v=10.4.3"></script>
<script src="/modules/contrib/ckeditor_accordion/js/accordion.frontend.min.js?st2xsw"></script>
<script src="/core/misc/jquery.form.js?v=4.3.0"></script>
<script src="/core/misc/progress.js?v=10.4.3"></script>
<script src="/core/assets/vendor/loadjs/loadjs.min.js?v=4.3.0"></script>
<script src="/core/misc/debounce.js?v=10.4.3"></script>
<script src="/core/misc/announce.js?v=10.4.3"></script>
<script src="/core/misc/message.js?v=10.4.3"></script>
<script src="/core/misc/ajax.js?v=10.4.3"></script>
<script src="/themes/contrib/stable/js/ajax.js?v=10.4.3"></script>
<script src="/core/misc/displace.js?v=10.4.3"></script>
<script src="/core/misc/jquery.tabbable.shim.js?v=10.4.3"></script>
<script src="/core/misc/position.js?v=10.4.3"></script>
<script src="/core/misc/dialog/dialog-deprecation.js?v=10.4.3"></script>
<script src="/core/misc/dialog/dialog.js?v=10.4.3"></script>
<script src="/core/misc/dialog/dialog.position.js?v=10.4.3"></script>
<script src="/core/misc/dialog/dialog.jquery-ui.js?v=10.4.3"></script>
<script src="/core/modules/ckeditor5/js/ckeditor5.dialog.fix.js?v=10.4.3"></script>
<script src="/core/misc/dialog/dialog.ajax.js?v=10.4.3"></script>
<script src="/profiles/dhsd8_gov/modules/custom/dhs_core/js/dhs_anchor_accordion_links.js?v=1.x"></script>
<script src="/themes/custom/dhs_uswds/assets/uswds/js/uswds-init.js?v=3.0.2"></script>
<script src="/themes/custom/dhs_uswds/assets/uswds/js/uswds.min.js?v=3.0.2"></script>
<script src="/libraries/slick-carousel/slick/slick.js?v=1.0.1"></script>
<script src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/js/aplayer-accordion.js?v=1.0.1"></script>
<script src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/js/accordion-expand-all.js?v=1.0.1"></script>
<script src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/js/meetselva-attrchange/js/attrchange.js?v=1.0.1"></script>
<script src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/js/sidebar-menu.js?v=1.0.1"></script>
<script src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/js/general.js?v=1.0.1"></script>
<script src="/profiles/dhsd8_gov/themes/custom/dhs_uswds_subtheme/js/opensearch_menu_tabs.js?v=1.0.1"></script>
<script src="https://siteimproveanalytics.com/js/siteanalyze_6025116.js" async></script>
<script src="https://cdn.jsdelivr.net/npm/js-cookie@3.0.1/dist/js.cookie.min.js"></script>
<script src="/modules/contrib/ableplayer/js/ableplayer.min.js?v=4.4.1"></script>
<script src="/modules/contrib/emerald_client/js/emerald.ableplayer.js?st2xsw"></script>
<script src="/modules/contrib/extlink/extlink.js?v=10.4.3"></script>
<script src="/profiles/dhsd8_gov/modules/contrib/extlink_extra/js/extlink_extra.js?st2xsw"></script>
<script src="/modules/contrib/google_analytics/js/google_analytics.js?v=10.4.3"></script>
<script src="/modules/contrib/uswds_ckeditor_integration/js/aftermarket/uswds_accordion.js?st2xsw"></script>
<script src="/modules/custom/wcm_survey/js/jquery.cookie.js?v=1.x"></script>
<script src="/modules/custom/wcm_survey/js/json3.min.js?v=1.x"></script>
<script src="/modules/custom/wcm_survey/js/wcm_survey.js?v=1.x"></script>

  </body>
</html>
